Lembre-se, antes de executar os arquivos date-fns.js, e, 
o arquivo moment.js, recomendo que executem o comando abaixo:

  npm install

Desta forma, irá instalar as bibliotecas que estão na propriedade
dependencies do arquivo package.json, após executar este comando
note que deverá ser criada a pasta /node_modules e dentro dela
deverá existir as pastas moment e date-fns.

Feito isso agora sim pode partir para a execução dos arquivos
date-fns.js e moment.js através dos seguintes comandos abaixo:
  node date-fns.js
  node moment.js